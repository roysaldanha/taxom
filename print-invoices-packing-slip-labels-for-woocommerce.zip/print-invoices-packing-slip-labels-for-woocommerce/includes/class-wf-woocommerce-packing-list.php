<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://www.webtoffee.com/
 * @since      2.5.0
 *
 * @package    Wf_Woocommerce_Packing_List
 * @subpackage Wf_Woocommerce_Packing_List/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      2.5.0
 * @package    Wf_Woocommerce_Packing_List
 * @subpackage Wf_Woocommerce_Packing_List/includes
 * @author     WebToffee <info@webtoffee.com>
 */
class Wf_Woocommerce_Packing_List {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    2.5.0
	 * @access   protected
	 * @var      Wf_Woocommerce_Packing_List_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    2.5.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    2.5.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;


	private static $stored_options=array();

	public static $no_image="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";

	public static $template_data_tb='wfpklist_template_data';

	public static $default_additional_checkout_data_fields=array(
        'SSN',
        'VAT'
    );

    public static $default_additional_data_fields=array(
        'Contact Number' => 'contact_number',
        'Email' => 'email',
        'SSN' => 'ssn',
        'VAT' => 'vat',
        'Customer Note' => 'cus_note',
    );

    public static $wf_packinglist_brand_color='080808';
    public static $loaded_modules=array();

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    2.5.0
	 */
	public function __construct()
	{
		if( defined( 'WF_PKLIST_VERSION' ) ) 
		{
			$this->version = WF_PKLIST_VERSION;
		} else {
			$this->version = '2.5.6';
		}
		if(defined('WF_PKLIST_PLUGIN_NAME'))
		{
			$this->plugin_name=WF_PKLIST_PLUGIN_NAME;
		}else
		{
			$this->plugin_name='wf-woocommerce-packing-list';
		}
		if(!$this->check_necessary())
		{
			return;
		}
		$this->load_dependencies();
		$this->set_locale();
		$this->define_common_hooks();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	private function check_necessary()
	{
		global $wpdb;
		$search_query = "SHOW TABLES LIKE %s";
		$tb=Wf_Woocommerce_Packing_List::$template_data_tb;
        $like = '%' . $wpdb->prefix.$tb.'%';
        if(!$wpdb->get_results($wpdb->prepare($search_query, $like), ARRAY_N)) 
        {
        	return false;
        	//wp_die(_e('Plugin not installed correctly','wf-woocommerce-packing-list'));
        }
        return true;	
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wf_Woocommerce_Packing_List_Loader. Orchestrates the hooks of the plugin.
	 * - Wf_Woocommerce_Packing_List_i18n. Defines internationalization functionality.
	 * - Wf_Woocommerce_Packing_List_Admin. Defines all hooks for the admin area.
	 * - Wf_Woocommerce_Packing_List_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    2.5.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wf-woocommerce-packing-list-loader.php';


		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wf-woocommerce-packing-list-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wf-woocommerce-packing-list-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-wf-woocommerce-packing-list-public.php';

		$this->loader = new Wf_Woocommerce_Packing_List_Loader();
		$this->plugin_admin = new Wf_Woocommerce_Packing_List_Admin( $this->get_plugin_name(), $this->get_version() );
		$this->plugin_public = new Wf_Woocommerce_Packing_List_Public( $this->get_plugin_name(), $this->get_version() );

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wf_Woocommerce_Packing_List_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    2.5.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Wf_Woocommerce_Packing_List_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}


	private function define_common_hooks()
	{
		$this->loader->add_action('init',$this,'run_necessary',10); //run some necessary function copied from old plugin
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    2.5.0
	 * @access   private
	 */
	private function define_admin_hooks() {
		
		$this->loader->add_action('wp_ajax_wf_advanced_settings',$this->plugin_admin,'advanced_settings');
		$this->loader->add_action('wp_ajax_wf_pklist_load_address_from_woo',$this->plugin_admin,'load_address_from_woo');
		
		$this->loader->add_action('admin_menu', $this->plugin_admin, 'admin_menu',11); /* Adding admin menu */
		$this->loader->add_action('add_meta_boxes',$this->plugin_admin, 'add_meta_boxes',11); /* Add print option metabox in order page */		
		
		// Add plugin settings link: 
		$this->loader->add_filter('plugin_action_links_'.plugin_basename(WF_PKLIST_PLUGIN_FILENAME),$this->plugin_admin,'plugin_action_links');

		//print action button and dropdown items
		$this->loader->add_filter('woocommerce_admin_order_actions',$this->plugin_admin,'add_print_action_button',10,2); //to add print option in the order list page action column
		$this->loader->add_action('manage_shop_order_posts_custom_column',$this->plugin_admin,'add_print_actions',10); /* Add print action buttons to action column */
		
		$this->loader->add_filter('bulk_actions-edit-shop_order',$this->plugin_admin,'alter_bulk_action',10); /* Add print buttons to order bulk actions */
				
		//frontend print action buttons
		$this->loader->add_action('woocommerce_order_details_after_order_table',$this->plugin_admin,'add_fontend_print_actions',10); /* Add print action buttons in user dashboard orders page */		
		
		//email print action buttons
		$this->loader->add_action('woocommerce_email_after_order_table',$this->plugin_admin,'add_email_print_actions',10); /* Add print action buttons in order */		
		
		//email attachment
		$this->loader->add_filter('woocommerce_email_attachments',$this->plugin_admin,'add_email_attachments',10,3); /* Add pdf attachments to order email */		
		
		$this->loader->add_filter('woocommerce_checkout_fields',$this->plugin_admin,'add_checkout_fields'); /* Add additional checkout fields */		

		$this->loader->add_action('init',$this->plugin_admin,'print_window',10); /* to print the invoice and packinglist */

		$this->plugin_admin->admin_modules();
		$this->plugin_public->common_modules();

		$this->loader->add_action('admin_enqueue_scripts',$this->plugin_admin, 'enqueue_styles' );
		$this->loader->add_action('admin_enqueue_scripts',$this->plugin_admin, 'enqueue_scripts' );

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    2.5.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$this->loader->add_action( 'wp_enqueue_scripts',$this->plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts',$this->plugin_public, 'enqueue_scripts' );
	}


	/**
	 * Some modules are not start by default. So need to initialize via code
	 *
	 * @since    2.5.0
	 */
	public static function load_modules($module_id)
	{
		if(Wf_Woocommerce_Packing_List_Public::module_exists($module_id) || Wf_Woocommerce_Packing_List_Admin::module_exists($module_id))
		{
			if(!isset(self::$loaded_modules[$module_id]))
			{
				$module_class='Wf_Woocommerce_Packing_List_'.ucfirst($module_id);
				self::$loaded_modules[$module_id]=new $module_class;
			}
			return self::$loaded_modules[$module_id];
		}
		else
		{
			return null;
		}
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    2.5.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     2.5.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     2.5.0
	 * @return    Wf_Woocommerce_Packing_List_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     2.5.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

	/**
	 * run some necessary function copied from old plugin
	 * @since     2.5.0
	 */
	public function run_necessary()
	{
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wf-legacy.php';	
		do_action('wt_run_necessary');
	}

	/**
	 * Generate tab head for settings page.
	 * method will translate the string to current language
	 * @since     2.5.0
	 */
	public static function generate_settings_tabhead($title_arr,$type="plugin")
	{	
		$out_arr=apply_filters("wf_pklist_".$type."_settings_tabhead",$title_arr);
		foreach($out_arr as $k=>$v)
		{			
			if(is_array($v))
			{
				$v=(isset($v[2]) ? $v[2] : '').$v[0].' '.(isset($v[1]) ? $v[1] : '');
			}
		?>
			<a class="nav-tab" href="#<?php echo $k;?>"><?php echo $v; ?></a>
		<?php
		}
	}

	public static function wf_encode($data) 
	{
        return rtrim(strtr(base64_encode($data),'+/','-_'),'=');
    }

    public static function wf_decode($data)
    {
        return base64_decode(str_pad(strtr($data,'-_','+/'),strlen($data)%4,'=',STR_PAD_RIGHT));
    }

    public static function generate_print_button_for_user($order,$order_id,$action,$label,$email_button=false)
    {
    	$wc_version=WC()->version;
		$billing_email=($wc_version< '2.7.0' ? $order->billing_email : $order->get_billing_email());
		$order_id_enc=self::wf_encode($order_id);
		$billing_email_enc=self::wf_encode($billing_email);
		$_nonce=wp_create_nonce(WF_PKLIST_PLUGIN_NAME);
		$wpml_language=defined('ICL_LANGUAGE_CODE') ? '&lang='.ICL_LANGUAGE_CODE : '';
		$invoice_url=esc_url(site_url('?attaching_pdf=1&print_packinglist=true&email='.$billing_email_enc.'&post='.$order_id_enc.'&type='.$action.'&user_print=1&_wpnonce='.$_nonce.$wpml_language));
        $style='';
        if($email_button)
        {
        	$style='background:#0085ba; border-color:#0073aa; box-shadow:0 1px 0 #006799; color:#fff; text-decoration:none; padding:10px; border-radius:10px; text-shadow:0 -1px 1px #006799, 1px 0 1px #006799, 0 1px 1px #006799, -1px 0 1px #006799;';
        }
        $button = '<a class="button button-primary" style="'.$style.'" target="_blank" href="'.$invoice_url.'">'.$label.'</a><br><br>';
        echo $button;
    }

	/**
	 * Get default settings
	 * @since     2.5.0
	 */
	public static function default_settings($base_id='')
	{
		$settings=array(
			'woocommerce_wf_packinglist_companyname'=>'',
			'woocommerce_wf_packinglist_logo'=>'',
			'woocommerce_wf_packinglist_footer'=>'',
			'woocommerce_wf_packinglist_sender_name'=>'',
			'woocommerce_wf_packinglist_sender_address_line1'=>'',
			'woocommerce_wf_packinglist_sender_address_line2'=>'',
			'woocommerce_wf_packinglist_sender_city'=>'',
			'wf_country'=>get_option('woocommerce_default_country') ? get_option('woocommerce_default_country') : '',
			'woocommerce_wf_packinglist_sender_postalcode'=>'',
			'woocommerce_wf_packinglist_sender_contact_number'=>'',
			'woocommerce_wf_packinglist_sender_vat'=>'',
			'woocommerce_wf_packinglist_preview'=>'enabled',
			'woocommerce_wf_packinglist_package_type'=>'single_packing', //just keeping to avoid errors
			'woocommerce_wf_packinglist_boxes'=>array(),
			'woocommerce_wf_add_rtl_support'=>'No',
		);
		if($base_id!='')
		{
			$settings=apply_filters('wf_module_default_settings',$settings,$base_id);
		}
		return $settings;
	}

	/**
	 * Reset to default settings
	 * @since     2.5.0
	 */
	public static function reset_to_default($option_name,$base_id='')
	{
		$settings=self::default_settings($base_id);
		return (isset($settings[$option_name]) ? $settings[$option_name] : '');
	}

	/**
	 * Get current settings.
	 * @since     2.5.0
	 */
	public static function get_settings($base_id='')
	{ 
		$settings=self::default_settings($base_id);
		$option_name=($base_id=="" ? WF_PKLIST_SETTINGS_FIELD : $base_id);
		$option_id=($base_id=="" ? 'main' : $base_id); //to store in the stored option variable
		self::$stored_options[$option_id]=get_option($option_name);
		if(!empty(self::$stored_options[$option_id])) 
		{
			$settings=wp_parse_args(self::$stored_options[$option_id],$settings);
		}
		//stripping escape slashes
		$settings=self::arr_stripslashes($settings);
		$settings=apply_filters('wf_pklist_alter_settings',$settings,$base_id);
		return $settings;
	}

	/**
	 * Delete current settings.
	 * @since     2.5.0
	 */
	public static function delete_settings($base_id='')
	{
		$option_name=($base_id=="" ? WF_PKLIST_SETTINGS_FIELD : $base_id);
		$option_id=($base_id=="" ? 'main' : $base_id); //to store in the stored option variable
		delete_option($option_name);
		unset(self::$stored_options[$option_id]);
	}

	protected static function arr_stripslashes($arr)
	{
		if(is_array($arr) || is_object($arr))
		{
			foreach($arr as &$arrv)
			{
				$arrv=self::arr_stripslashes($arrv);
			}
			return $arr;
		}else
		{
			return stripslashes($arr);
		}
	}

	/**
	 * Update current settings.
	 * @arg $base_id module id
	 * @since     2.5.0
	 */
	public static function update_settings($the_options,$base_id='')
	{
		if($base_id!="" && $base_id!='main') //main is reserved so do not allow modules named main
		{
			self::$stored_options[$base_id]=$the_options;
			update_option($base_id,$the_options);
		}
		if($base_id=="")
		{
			self::$stored_options['main']=$the_options;
			update_option(WF_PKLIST_SETTINGS_FIELD,$the_options);
		}
	}

	/**
	 * Update option value,
	 * @since     2.5.0
	 * @return mixed
	 */
	public static function update_option($option_name,$value,$base='')
	{
		$the_options=self::get_settings($base);
		$the_options[$option_name]=$value;
		self::update_settings($the_options,$base);
	}

	/**
	 * Get option value, move the option to common option field if it was individual
	 * @since     2.5.0
	 * @return mixed
	 */
	public static function get_option($option_name,$base='',$the_options=null)
	{
		if(is_null($the_options))
		{
			$the_options=self::get_settings($base);
		}
		$vl=isset($the_options[$option_name]) ? $the_options[$option_name] : false;
		$vl=apply_filters('wf_pklist_alter_option',$vl,$the_options,$option_name,$base);
		return $vl;
	}

	public static function get_module_id($module_base)
	{
		return WF_PKLIST_POST_TYPE.'_'.$module_base;
	}

    public static function is_from_address_available()
    {
        if((self::get_option('woocommerce_wf_packinglist_sender_name')=='' || 
        	self::get_option('woocommerce_wf_packinglist_sender_address_line1')=='' || 
        	self::get_option('woocommerce_wf_packinglist_sender_city') == '' || 
        	self::get_option('wf_country') == '' || 
        	self::get_option('woocommerce_wf_packinglist_sender_postalcode') == '')) 
        {
            return false;
        } else
        {
            return true;
        }
    }
}