(function( $ ) {
	//'use strict';
	$(function() {
		wf_invoice_update_order_status_to_email_select_box();
		$('#woocommerce_wf_generate_for_orderstatus_st').on('change',function(){
			wf_invoice_update_order_status_to_email_select_box();
		})

	});
	function wf_invoice_update_order_status_to_email_select_box()
	{
		var attch_inv_elm=$('#woocommerce_wf_attach_invoice_st');
		var attch_inv_vl=attch_inv_elm.val();
		attch_inv_vl=attch_inv_vl!==null ? attch_inv_vl : new Array();
		var html='';
		$('#woocommerce_wf_generate_for_orderstatus_st').find('option:selected').each(function(){
			var slcted=$.inArray($(this).val(),attch_inv_vl)==-1 ? '' : 'selected';
			html+='<option value="'+$(this).val()+'" '+slcted+'>'+$(this).html()+'</option>';
		});
		attch_inv_elm.html(html).trigger('change');
	}


	jQuery('.wf_invoice_number_settings_form').submit(function(e){
		e.preventDefault();
		var data=jQuery(this).serialize();
		var submit_btn=jQuery(this).find('input[type="submit"]');
		var spinner=submit_btn.siblings('.spinner');
		spinner.css({'visibility':'visible'});
		submit_btn.css({'opacity':'.5','cursor':'default'}).prop('disabled',true);			
		jQuery.ajax({
			url:wf_pklist_params.ajaxurl,
			type:'POST',
			data:data+'&action=wf_reset_invoice_number&_wpnonce='+wf_pklist_params.nonces.wf_packlist,
			success:function(data)
			{
				spinner.css({'visibility':'hidden'});
				submit_btn.css({'opacity':'1','cursor':'pointer'}).prop('disabled',false);
				wf_notify_msg.success(wf_pklist_params.msgs.settings_success);
			},
			error:function () 
			{
				spinner.css({'visibility':'hidden'});
				submit_btn.css({'opacity':'1','cursor':'pointer'}).prop('disabled',false);
				wf_notify_msg.error(wf_pklist_params.msgs.settings_error);
			}
		});
	});


	function wf_toggle_invoice_number_fields()
	{
		var vl=$('#woocommerce_wf_invoice_number_format').val();
		var number_tr=$('[name="woocommerce_wf_invoice_as_ordernumber"]').parents('tr');
		var prefix_tr=$('[name="woocommerce_wf_invoice_number_prefix"]').parents('tr');
		var postfix_tr=$('[name="woocommerce_wf_invoice_number_postfix"]').parents('tr');
		var start_tr=$('#woocommerce_wf_invoice_start_number_tr');
		number_tr.hide().find('th label').css({'padding-left':'0px'});
		prefix_tr.hide().find('th label').css({'padding-left':'0px'});
		postfix_tr.hide().find('th label').css({'padding-left':'0px'});
		start_tr.hide().find('th label').css({'padding-left':'0px'});

		$('.form-table th label').css({'float':'left','width':'100%'});

		var num_reg=/\[number\]/gm;
		var pre_reg=/\[prefix\]/gm;
		var pos_reg=/\[suffix\]/gm;

		if(vl.search(num_reg)>=0)
		{
			number_tr.show().find('th label').animate({'padding-left':'15px'});
			if($('[name="woocommerce_wf_invoice_as_ordernumber"]:checked').val()=='No')
			{
				start_tr.show().find('th label').animate({'padding-left':'30px'});
			}
		}
		if(vl.search(pre_reg)>=0)
		{  
			prefix_tr.show().find('th label').animate({'padding-left':'15px'});
		}
		if(vl.search(pos_reg)>=0)
		{
			postfix_tr.show().find('th label').animate({'padding-left':'15px'});
		}
	}
	$('#woocommerce_wf_invoice_number_format').change(function(){
		wf_toggle_invoice_number_fields();
	});
	wf_toggle_invoice_number_fields();

	$('.wf_inv_num_frmt_hlp_btn').click(function(){
		var trgt_field=$(this).attr('data-wf-trget');
		$('.wf_inv_num_frmt_hlp').attr('data-wf-trget',trgt_field);
		wf_popup.showPopup($('.wf_inv_num_frmt_hlp'));
	});

	$('.wf_inv_num_frmt_append_btn').click(function(){
		var trgt_elm_name=$(this).parents('.wf_inv_num_frmt_hlp').attr('data-wf-trget');
		var trgt_elm=$('[name="'+trgt_elm_name+'"]'); 
		var exst_vl=trgt_elm.val();
		var cr_vl=$(this).text();
		trgt_elm.val(exst_vl+cr_vl);
		wf_popup.hidePopup();
	});

	/* sample pdf generation */
	$('.wf_sample_pdf_options_btn').click(function(){
		var elm=$('.wf_sample_pdf_options');
		if(elm.height()<=40)
		{
			elm.css({'height':'120px','border-color':'#efefef'});
		}else
		{
			elm.css({'height':'40px','border-color':'#fff'});
		}
	});
	$('[name="wf_sample_pdf_order_no"]').keyup(function(e){
		var order_id=$(this).val();
		$('.wf_sample_pdf_order_no_preview').html(order_id);
		if(e.keyCode==13)
		{
			$('.wf_download_sample_pdf').click();
		}
	});
	var sample_pdf_order_id=$('[name="wf_sample_pdf_order_no"]').val();
	$('.wf_sample_pdf_order_no_preview').html(sample_pdf_order_id);
	var sample_pdf_onprg=false;
	$('.wf_download_sample_pdf').click(function(){
		if(sample_pdf_onprg){ return false; }
		var order_id=$.trim($('[name="wf_sample_pdf_order_no"]').val());
		if(order_id!="")
		{
			var codeview_html=(typeof wf_code_editor!='undefined' ? wf_code_editor.getDoc().getValue() : $('#wfte_code').val());
			var data=
			{
				'action':'wt_generate_sample_pdf',
				'_wpnonce':wf_pklist_params.nonces.wf_packlist,
				'codeview_html':codeview_html,
				'order_id':order_id
			};
			
			var html_bck=$(this).html();
			$('.wf_sample_pdf_options').css({'height':'40px'});
			$('.wf_sample_pdf_options_btn').hide();
			var spinner=$('.wf_sample_pdf_options').find('.spinner');
			spinner.show().css({'visibility':'visible'});
			$(this).html(wf_woocommerce_packing_list_invoice.msgs.generating+'...');
			sample_pdf_onprg=true;

			jQuery.ajax({
				url:wf_pklist_params.ajaxurl,
				type:'POST',
				data:data,
				dataType:'json',
				success:function(data)
				{
					sample_pdf_onprg=false;	
					$('.wf_sample_pdf_options_btn').show();
					$('.wf_download_sample_pdf').html(html_bck);
					spinner.hide().css({'visibility':'hidden'});
					if(data.status==1)
					{
						window.open(data.pdf_url);
					}else
					{
						wf_notify_msg.error(data.msg);
					}				
				},
				error:function() 
				{
					sample_pdf_onprg=false;
					$('.wf_sample_pdf_options_btn').show();
					$('.wf_download_sample_pdf').html(html_bck);
					spinner.hide().css({'visibility':'hidden'});
					wf_notify_msg.error(wf_woocommerce_packing_list_invoice.msgs.error);
				}
			});
		}else
		{
			wf_notify_msg.error(wf_woocommerce_packing_list_invoice.msgs.enter_order_id);
			$('.wf_sample_pdf_options').css({'height':'120px','border-color':'#efefef'});
			$('[name="wf_sample_pdf_order_no"]').focus();
		}
	});
	/* sample pdf generation */

})( jQuery );