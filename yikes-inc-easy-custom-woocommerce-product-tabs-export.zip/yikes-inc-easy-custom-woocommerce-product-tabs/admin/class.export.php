<?php

class YIKES_Custom_Product_Tabs_Export {

	public function __construct() {

		add_filter( 'woocommerce_product_export_product_default_columns', array( $this, 'add_custom_product_tabs_header_to_product_export' ), 10, 1 );

		add_filter( 'woocommerce_product_export_product_column_yikes_woo_products_tabs', array( $this, 'add_custom_product_tabs_data_to_product_export' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_images', array( $this, 'add_custom_product_tabs_data_to_product_export1' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_360', array( $this, 'add_custom_product_tabs_data_to_product_export2' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_taxonomy', array( $this, 'add_custom_product_tabs_data_to_product_export3' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_synonyms', array( $this, 'add_custom_product_tabs_data_to_product_export4' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_species_description', array( $this, 'add_custom_product_tabs_data_to_product_export5' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_spatial_distribution', array( $this, 'add_custom_product_tabs_data_to_product_export6' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_status_habitat_habit', array( $this, 'add_custom_product_tabs_data_to_product_export7' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_dna_sequence', array( $this, 'add_custom_product_tabs_data_to_product_export8' ), 10, 3 );

		add_filter( 'woocommerce_product_export_product_column_yikes_reference', array( $this, 'add_custom_product_tabs_data_to_product_export9' ), 10, 3 );
	}

	public function add_custom_product_tabs_header_to_product_export( $columns ) {

		if ( apply_filters( 'yikes-woo-do-not-export-tabs', false ) === true ) {
			return $columns;
		}

		$columns['yikes_woo_products_tabs'] = 'Is Custom Tabs';
		$columns['yikes_images'] = 'Custom Images';
		$columns['yikes_360'] = 'Custom 360 Map';			
		$columns['yikes_taxonomy'] = 'Custom Taxonomy';
		$columns['yikes_synonyms'] = 'Custom Synonyms';			
		$columns['yikes_species_description'] = 'Custom Species Description';		
		$columns['yikes_spatial_distribution'] = 'Custom Spatial Distribution';	
		$columns['yikes_status_habitat_habit'] = 'Custom Status Habitat Habit';
		$columns['yikes_dna_sequence'] = 'Custom DNA';
		$columns['yikes_reference'] = 'Custom Reference';

		return $columns;
	}

	public function add_custom_product_tabs_data_to_product_export( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$tabs = ! empty( $tabs ) ? 'Yes' : '';

		return $tabs;
	}

	public function add_custom_product_tabs_data_to_product_export1( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true ); 

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'images') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}

	public function add_custom_product_tabs_data_to_product_export2( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == '360') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}

	public function add_custom_product_tabs_data_to_product_export3( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'taxonomy') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}
	public function add_custom_product_tabs_data_to_product_export4( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'synonyms') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}
	public function add_custom_product_tabs_data_to_product_export5( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'species-description') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}
	public function add_custom_product_tabs_data_to_product_export6( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'spatial-distribution') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}
	public function add_custom_product_tabs_data_to_product_export7( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'status-habitat-habit') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}
	public function add_custom_product_tabs_data_to_product_export8( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'dna-sequence') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}
	public function add_custom_product_tabs_data_to_product_export9( $value, $product, $column_id ) {

		$tabs = get_post_meta( $product->get_id(), 'yikes_woo_products_tabs', true );

		$custom_tabs = unserialize($tabs);
		$content = '';
		foreach ($custom_tabs as $key => $custom_tab) {
			if($custom_tab['id'] == 'reference') {
				$content = $custom_tab['content'];
			}
		}

		return $content;
	}
}

new YIKES_Custom_Product_Tabs_Export();